<div class="container mt-5 " id="home" style="background: linear-gradient(to left, #0176ff, #00b7ff);">
    <!-- <h2 class="text-center mb-4 mt-5">Solina Itu Apa sih?</h2>
        <div class="card">
            <div class="card-body">
                <p class="card-text">Selamat datang di Solina, penyedia jasa sedot WC online terdepan di Indonesia! Kami memahami bahwa masalah WC yang mampet atau septic tank yang penuh dapat menjadi pengalaman yang tidak menyenangkan dan mengganggu kenyamanan rumah tangga atau tempat usaha Anda. Oleh karena itu, kami hadir untuk memberikan solusi cepat, profesional, dan terpercaya untuk kebutuhan sanitasi Anda.</p>
                <p class="card-text">Dengan Solina, Anda tidak perlu lagi repot mencari layanan sedot WC yang handal. Melalui platform online kami, Anda dapat dengan mudah memesan jasa sedot WC kapan saja dan di mana saja. Kami bangga dengan komitmen kami untuk menyediakan layanan berkualitas tinggi dengan harga yang kompetitif, memastikan bahwa setiap pelanggan mendapatkan kepuasan maksimal dari layanan kami.</p>
                <p class="card-text">Terima kasih telah mempercayakan kebutuhan sedot WC Anda kepada Solina. Kami berkomitmen untuk selalu memberikan layanan terbaik dan solusi sanitasi yang efisien untuk kenyamanan Anda.</p>
            </div>
        </div> -->


    <div class="slider-area" id="slider-area">
        <div class="container">
            <div class="row align-items-center m-5">
                <div class="col-12 col-md-6 col-lg-6 text-md-center text-lg-left wow fadeInLeft content-margin" data-wow-duration="1.5s" data-wow-delay="1.2s" style="visibility: visible; animation-duration: 1.5s; animation-delay: 1.2s; animation-name: fadeInLeft;">
                    <div class="area-heading text-center text-lg-left">
                        <h1 class="main-font text-white font-weight-bold mb-4 mt-5">SOLINA<span class="d-block">JASA SEDOT WC </span></h1>
                        <p class="text-white alt-font mb-5">Selamat datang di Solina, penyedia jasa sedot WC online terdepan di Indonesia! Kami memahami bahwa masalah WC yang mampet atau septic tank yang penuh dapat menjadi pengalaman yang tidak menyenangkan dan mengganggu kenyamanan rumah tangga atau tempat usaha Anda. Oleh karena itu, kami hadir untuk memberikan solusi cepat, profesional, dan terpercaya untuk kebutuhan sanitasi Anda.</p>
                        <a href="./admin/table_pesanan.php" target="_blank" class="btn btn-primary" >Booking Segera</a> <a href="https://wa.me/6285339938989" target="_blank" class="btn btn-primary" >Pesan Sekarang</a>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6 text-right image-order wow fadeInRight" data-wow-duration="1.5s" data-wow-delay="1.2s" style="visibility: visible; animation-duration: 1.5s; animation-delay: 1.2s; animation-name: fadeInRight;">
                    <div class="slider-image m-5">
                     <div class="card">   <img src="https://sedotwcserang.com/lestarisolusindo/img/cara-mengatasi-toilet-bau.jpg" class="w-100 mx-auto d-block " alt="#"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Author Skills -->

    <canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="1295" height="1"></canvas>

</div>