
<div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-6 text-center">
                        <div class="user-img"><img src="lestarisolusindo/img/lestari-solusindo.jpg" class="rounded-circle" alt="logo-lestari-solusindo"></div>
                        <h4 class="user-name">CV. Lestari Solusindo</h4>
                        <p class="user-designation">cvlestarisolusindo@gmail.com</p>
                        <a href="tel:+6281119967999"><p class="user-designation">+62 811-1996-7999</p></a> 
                        <a href="tel:+6285933553589"><p class="user-designation">+62 859-3355-3589</p></a> 
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="row">
                            <div class="col-12" id="result"></div>
                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15867.910113652353!2d106.1920099!3d-6.1337215!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e41f7a02514a2df%3A0x384c2a3c22630a81!2sSedot%20Wc%20Serang%20-%20CV.%20Lestari%20Solusindo!5e0!3m2!1sid!2sid!4v1693796266305!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        